export default function renderTournament() {
    return `

		<!DOCTYPE html>
		<html>
		<head>
			<title>Render Tournament</title>
		</head>
		<body>
			<h3>Render Tournament</h3>
		</body>
		</html>


`;
}
