# pong_app/consumers.py
import json
from channels.generic.websocket import WebsocketConsumer

class PongConsumer(WebsocketConsumer):
    players = []

    def connect(self):
        self.accept()
        if len(PongConsumer.players) < 2:
            PongConsumer.players.append(self)
            self.player_id = len(PongConsumer.players)
            self.send(text_data=json.dumps({
                'type': 'connection_established',
                'player_id': self.player_id
            }))
        else:
            self.close()

    def disconnect(self, close_code):
        if self in PongConsumer.players:
            PongConsumer.players.remove(self)

    def receive(self, text_data):
        data = json.loads(text_data)
        if 'type' in data and data['type'] == 'game_update':
            self.send_game_update(data)

    def send_game_update(self, data):
        for player in PongConsumer.players:
            if player != self:
                player.send(text_data=json.dumps(data))
